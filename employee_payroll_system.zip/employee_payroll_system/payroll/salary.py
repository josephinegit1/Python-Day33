from payroll.tax import calculate_tax

def calculate_net_salary(base_salary):
    tax_amount = calculate_tax(base_salary)
    net_salary = base_salary - tax_amount
    return round(net_salary, 2), tax_amount
