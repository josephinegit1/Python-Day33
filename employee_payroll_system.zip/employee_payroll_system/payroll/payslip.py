from datetime import datetime

def generate_payslip(employee, net_salary, tax):
    print("\n====== Payslip ======")
    print(f"Date: {datetime.now().strftime('%Y-%m-%d')}")
    print(f"Employee ID: {employee.emp_id}")
    print(f"Name: {employee.name}")
    print(f"Base Salary: ₹{employee.base_salary}")
    print(f"Tax Deducted: ₹{tax}")
    print(f"Net Salary: ₹{net_salary}")
    print("=====================\n")
