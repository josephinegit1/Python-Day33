from payroll.employee import Employee
from payroll.salary import calculate_net_salary
from payroll.payslip import generate_payslip

def main():
    print("=== Employee Payroll System ===")
    emp_id = input("Enter Employee ID: ")
    name = input("Enter Employee Name: ")
    base_salary = float(input("Enter Base Salary: ₹"))

    employee = Employee(emp_id, name, base_salary)
    net_salary, tax = calculate_net_salary(employee.base_salary)
    generate_payslip(employee, net_salary, tax)

if __name__ == "__main__":
    main()
