from library import catalog, search, reader

def main():
    print("=== 📚 eBook Library Organizer ===")

    while True:
        print("\nOptions:")
        print("1. List all eBooks")
        print("2. Search eBooks")
        print("3. Open an eBook")
        print("4. Exit")

        choice = input("Enter choice: ")

        if choice == '1':
            books = catalog.list_ebooks()
            print("\n📚 Available eBooks:")
            for b in books:
                print("-", b)
        elif choice == '2':
            keyword = input("Enter keyword to search: ")
            results = search.search_ebooks(keyword)
            print("\n🔍 Search Results:")
            for r in results:
                print("-", r)
        elif choice == '3':
            name = input("Enter full eBook filename: ")
            reader.open_ebook(name)
        elif choice == '4':
            print("👋 Exiting...")
            break
        else:
            print("❌ Invalid choice. Try again.")

if __name__ == "__main__":
    main()
