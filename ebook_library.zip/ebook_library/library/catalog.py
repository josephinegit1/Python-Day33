import os
import glob
from . import config

def list_ebooks():
    pattern = os.path.join(config.EBOOK_FOLDER, '*')
    files = glob.glob(pattern)
    ebooks = [os.path.basename(f) for f in files if os.path.splitext(f)[1] in config.SUPPORTED_EXTENSIONS]
    return ebooks
