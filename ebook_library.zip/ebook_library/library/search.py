import re
from . import catalog

def search_ebooks(keyword):
    ebooks = catalog.list_ebooks()
    result = [book for book in ebooks if re.search(keyword, book, re.IGNORECASE)]
    return result
