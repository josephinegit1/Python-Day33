import os
from . import config

def open_ebook(filename):
    path = os.path.join(config.EBOOK_FOLDER, filename)
    if not os.path.exists(path):
        print("❌ File not found.")
        return

    print(f"\n📖 Opening '{filename}'...")
    print("🔍 Preview (first 200 characters):\n")

    try:
        with open(path, 'r', encoding='utf-8') as f:
            print(f.read(200))
    except Exception as e:
        print(f"⚠️ Can't open this file type. ({e})")
