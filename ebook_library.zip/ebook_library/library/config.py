import os

# Folder where eBooks are stored (e.g., .pdf or .epub)
EBOOK_FOLDER = os.path.join(os.path.dirname(__file__), '..', 'ebooks')
SUPPORTED_EXTENSIONS = ['.pdf', '.epub', '.txt']
