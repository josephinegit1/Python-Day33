import numpy as np

arr = np.array([10,20,30,40])
print("Array:",arr)
print("Mean:",np.mean(arr))
print("Standard Deviation:",np.std(arr))

